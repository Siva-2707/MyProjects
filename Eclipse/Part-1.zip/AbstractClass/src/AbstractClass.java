abstract class Human{
	public abstract void eat();
	public abstract void sleep();		  // Abstract class cannot be instantiated (i.e) For abstract classes no object can be created.
	
	public void drink() {
		System.out.println("Drinking");   // Abstract classes can have methods defined inside it. 
	}									 // In interface only method declaration is allowed, No methods can be defined in it. 
												//But from java 8 it can be done using default access specifier in the method.
}										// It is compulsory to define all the abstract methods in the inherited child class.
class Men extends Human{
	public void eat() {
		System.out.println("Eating");
	}
	public void sleep() {
		System.out.println("Sleeping");
	}
}
class Women extends Men {
	public void makeUp() {
	System.out.println("MakeUp");	
	}
	
	
}
public class AbstractClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Women w =new Women();
		Men m =new Men();
		w.eat();
		w.sleep();
		w.makeUp();
		m.eat();
		m.sleep();
		w.drink();

	}

}
