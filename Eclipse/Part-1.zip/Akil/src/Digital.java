import java.util.*;
public class Digital {
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String s=sc.nextLine();
		int n=s.length();
String s1=s.substring(0,1);
String s2=s.substring(1,n);
String s3=s.substring(n-1,n);
String s4=s.substring(0,n-1);

String a=s2.concat(s1);
String b=s3.concat(s4);
if(a.equals(b))
	System.out.println("1");
else
    System.out.println("0");
		
sc.close();
	}

}
