import java.util.Scanner;

public class IRA {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Movie mv[] = new Movie[4];
		for(int i=0;i<4;i++) {
			mv[i]= new Movie(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.nextInt());
		}
		String val = sc.next();
		
		double ans = findAvgBudgetForGenre(mv, val);
		if(ans!=0)
			System.out.println(ans);
		else
			System.out.println("No Movie available");
		
		Movie m = findMovienameWithThirdHighestBudget(mv);
		if(m==null)
			System.out.println("No movie available");
		else
			System.out.println(m.getMovieName());
	}
	
	public static double findAvgBudgetForGenre(Movie mv[], String val) {
		double result =0;
		
		int count=0;
		for(int i=0;i<4;i++) {
		if(mv[i].getGenre().equalsIgnoreCase(val)) {
			result+=mv[i].getBudget();
			count++;
		}
		}
		if(count==0)
			return 0;
		
		return result/count;
	}
	
	public static Movie findMovienameWithThirdHighestBudget(Movie mv[]) {
		Movie temp[] = new Movie[4];
		for(int i=0;i<4;i++) {
			for(int j=i+1;j<4;j++) {
				if(mv[i].getBudget()==mv[j].getBudget())
					return null;
				if(mv[i].getBudget()<mv[j].getBudget()) {
					temp[i]=mv[i];
					mv[i]=mv[j];
					mv[j]=temp[i];
				}
			}
		}	
		return mv[2];
	}

}
class Movie{
	private int movieId;
	private String movieName, company, genre;
	private int budget;
	
	
	public Movie(int movieId, String movieName, String company, String genre, int budget) {
		this.movieId = movieId;
		this.movieName = movieName;
		this.company = company;
		this.genre = genre;
		this.budget = budget;
	}


	public int getMovieId() {
		return movieId;
	}


	public String getMovieName() {
		return movieName;
	}


	public String getCompany() {
		return company;
	}


	public String getGenre() {
		return genre;
	}


	public int getBudget() {
		return budget;
	}

}
