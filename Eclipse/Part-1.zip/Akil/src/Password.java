import java.util.Scanner;
import java.lang.Character;

public class Password {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		String str = sc.next();
		boolean result = false; 
		if(str.length()<15 && str.length()>8)
			result = true;
		char arr[] = str.toCharArray();
		boolean upperCase = false, lowerCase = false, digit = false, special =false;
		for(int i=0;i<arr.length;i++) {
			if(!upperCase)
				upperCase = Character.isUpperCase(arr[i]);
			if(!lowerCase)
				lowerCase = Character.isLowerCase(arr[i]);
			if(!digit)
				digit = Character.isDigit(arr[i]);
			if(!special)
				special = (!Character.isAlphabetic(arr[i]) && !Character.isDigit(arr[i]));
			}
		if( upperCase && lowerCase && digit && special && result)
			System.out.println(str +" is a valid password");
		else
			System.out.println(str +" is a invalid password");
				
		}
		
		

	}
