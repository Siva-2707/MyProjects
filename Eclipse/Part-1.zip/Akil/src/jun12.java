
import java.util.*;

public class jun12 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        Song songs[] = new Song[5];

        for (int i=0; i<5; i++) {
            int songId = sc.nextInt();
            sc.nextLine();
            String title = sc.nextLine();
            
            String artist = sc.nextLine();
//            sc.nextLine();
            double duration = sc.nextDouble();

            songs[i] = new Song(songId, title, artist, duration);
        }

//        for (Song s : songs)
//            System.out.println(s.getArtist());
        
        StringBuffer sb1 = new StringBuffer();
        sb1.append(sc.nextLine());
        StringBuffer sb2 = new StringBuffer();
        sb2.append(sc.nextLine());

        String artist1 = sb1.toString();        
        String artist2 = sb2.toString();
        
        System.out.println();

        System.out.println(sb1+ " , " + sb2);

        double totalDuration = findSongDurationForArtist(songs, artist1);
        if (totalDuration == 0)
            System.out.println("There are no songs with given artist");
        else
            System.out.println(totalDuration);

        Song artistSongs[] = getSongsInAscendingOrder(songs, artist2);
        if (artistSongs == null)
            System.out.println("There are no songs with given artist");
        else
            for (Song s : artistSongs) {
                System.out.println(s.getSongId());
                System.out.println(s.getTitle());
            }


    }

    static double findSongDurationForArtist(Song songs[], String artist) {
        double totalDuration = 0;

        for (Song s : songs) {
            if (s.getArtist().equalsIgnoreCase(artist))
                totalDuration += s.getDuration();
        }

        return totalDuration;
    }

    static Song[] getSongsInAscendingOrder(Song songs[], String artist) {
        int len = 0;

        for (Song s : songs) {
//            System.out.println(s.getArtist() + " " + artist);
            if (s.getArtist().equalsIgnoreCase(artist)) {
                len++;
            }
        }

//        System.out.println(len);

        if (len == 0)
            return null;
        else {
            Song artistSongs[] = new Song[len];
            int position = 0;
            for (Song s : songs)
                if (s.getArtist().equalsIgnoreCase(artist))
                    artistSongs[position++] = s;

            for (int i=0; i<len; i++)
                for (int j=0; j<len; j++) {
                    if (artistSongs[i].getDuration() > artistSongs[j].getDuration()) {
                        Song temp;
                        temp = artistSongs[i];
                        artistSongs[i] = artistSongs[j];
                        artistSongs[j] = temp;
                    }
                }
            return artistSongs;
        }
    }

}

class Song {
    private int songId;
    private String title, artist;
    private double duration;

    public Song(int songId, String title, String artist, double duration) {
        this.songId = songId;
        this.title = title;
        this.artist = artist;
        this.duration = duration;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }
}