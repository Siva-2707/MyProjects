package com.tcs.ilp;

public class Account {
	int accountNumber;
	String accountHolderName;
	double balance;
	String type;
	
	Account(){ //Default Constructor (Values are given in Constructor execution)
		accountNumber=1;
		accountHolderName="Rama";
		balance=1000;
		type="Savings";
	}
	
	Account(int accountNumber,String accountHolderName,double balance, String type){ //Parameterized Constructor (Values are passed as parameters)
		this.accountNumber=accountNumber;
		this.accountHolderName=accountHolderName;
		this.balance=balance;
		this.type=type;
	}
	Account(Account account){ //Copy constructor 
		this.accountNumber=account.accountNumber;
		this.accountHolderName=account.accountHolderName;
		this.balance=account.balance;
		this.type=account.type;
		
	}
}
