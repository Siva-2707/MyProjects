package com.tcs.ilp;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1= new Account(1,"Shree",2000,"Current");
		
		  /*account1.accountNumber=1; 
		  account1.accountHolderName="Rama";
		  account1.balance=1000; 
		  account1.type="Savings";*/
		 
		
		Account account2= new Account(2,"Rama",1000,"Savings");//Parameterized Constructor
		Account account3= new Account(account2); // Copy Constructor
		/*
		 * account2.accountNumber=2; account2.accountHolderName="Shree";
		 * account2.balance=1500; account2.type="Current";
		 */
		
		
		System.out.println("Account no: "+account1.accountNumber);
		System.out.println("Account Holder Name: "+account1.accountHolderName);
		System.out.println("Account Balance: "+account1.balance);
		System.out.println("Account type: "+account1.type);
		
		System.out.println();
		
		System.out.println("Account no: "+account2.accountNumber);
		System.out.println("Account Holder Name: "+account2.accountHolderName);
		System.out.println("Account Balance: "+account2.balance);
		System.out.println("Account type: "+account2.type);
		
		System.out.println();
		
		System.out.println("Account no: "+account3.accountNumber);
		System.out.println("Account Holder Name: "+account3.accountHolderName);
		System.out.println("Account Balance: "+account3.balance);
		System.out.println("Account type: "+account3.type);

	}

}
