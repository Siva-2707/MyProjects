package com.tcs.ilp;

public class Account {
	int accountNumber;
	String accountHolderName;
	double balance;
	String type;
	
	Account(int accountNumber,String accountHolderName,double balance, String type){ //Parameterized Constructor (Values are passed as parameters)
		this.accountNumber=accountNumber;
		this.accountHolderName=accountHolderName;
		this.balance=balance;
		this.type=type;
	}
	Account(int accountNumber,String accountHolderName){
		this.accountNumber=accountNumber;
		this.accountHolderName=accountHolderName;
		this.balance=5000;
		this.type="CurrentAccount";
	}
	public double calculateIntrest(double principal,float rateOfIntrest) {
		double principleAfterIntrest=principal+principal*rateOfIntrest/100;
		return principleAfterIntrest;
	}
	public double calculateIntrest(double principle,float rateOfIntrest,int numberOfYears) {
		double principleAfterIntrest=principle*Math.pow(1+rateOfIntrest/(numberOfYears*100), numberOfYears);
		return principleAfterIntrest;
	}
	
}
