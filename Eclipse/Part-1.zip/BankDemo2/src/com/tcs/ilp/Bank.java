package com.tcs.ilp;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1= new Account(1,"Shree",1000,"Savings");
		
		System.out.println("Account no: "+account1.accountNumber);
		System.out.println("Account Holder Name: "+account1.accountHolderName);
		System.out.println("Account Balance: "+account1.balance);
		System.out.println("Account type: "+account1.type);
		
		double balanceWithIntrest=account1.calculateIntrest(account1.balance, 12);
		account1.balance=balanceWithIntrest;
		
		System.out.println("Account1 details after intrest Calculation");
		
		System.out.println("Account no: "+account1.accountNumber);
		System.out.println("Account Holder Name: "+account1.accountHolderName);
		System.out.println("Account Balance: "+account1.balance);
		System.out.println("Account type: "+account1.type);
		
		Account account2=new Account(2, "Krish");
		
		System.out.println("Account no: "+account2.accountNumber);
		System.out.println("Account Holder Name: "+account2.accountHolderName);
		System.out.println("Account Balance: "+account2.balance);
		System.out.println("Account type: "+account2.type);
		
		double balanceWithCompoundIntrest=account2.calculateIntrest(account2.balance, 12, 4);
		account2.balance=balanceWithCompoundIntrest;
		
		System.out.println("Account2 details after Compound intrest Calculation");
		
		System.out.println("Account no: "+account2.accountNumber);
		System.out.println("Account Holder Name: "+account2.accountHolderName);
		System.out.println("Account Balance: "+account2.balance);
		System.out.println("Account type: "+account2.type);
	}
	

}
