import java.util.*;

public class ArrayList_Demo {
	
	public static void main(String args[]) {
		Integer arr[] = new Integer[]{1,2,3,4,5,6,1,2,3};
		List <Integer> a = Arrays.asList(arr);
		ArrayList <Integer> values = new ArrayList <>(a); // <Integer> specifies the type of data that the collection can accept.
													// Specifying the type of data is called Generics. Its called generic type.
		values.add(7);
		values.add(8);
		System.out.println(values);
		System.out.println(values.indexOf(2));
		
		String ar[] = new String[] {"Siva","Rajesh","Bala"};
		List<String> s = Arrays.asList(ar);
		ArrayList<String> al = new ArrayList<>(s);
		 
		Collections.sort(al);
		
		Iterator<String> it = al.iterator();
		int i=1;
		while(it.hasNext()) {
			System.out.println("Iteration:"+i+" "+it.next());
			i++;
		}
		
		ArrayList<String> names = new ArrayList<>();
		names.add("Ravi");
		names.add("Raja");
		names.add("Kumar");
		
		int code = names.hashCode();
		System.out.println(code);
		
		System.out.println("New List names: "+names);
		
		al.addAll(2,names);
		System.out.println("Adding: "+al);
		Collections.sort(al);
		System.out.println("Sorting: "+al);
		al.removeAll(names);
		System.out.println("Removing Names: "+al);
		al.remove(1);
		System.out.println("Removing Index 1: "+al);
		al.clear();
		
		System.out.println("Clearing List: "+al);

	}

}
