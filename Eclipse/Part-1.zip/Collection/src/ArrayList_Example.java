import java.util.*;

public class ArrayList_Example {

	public static void main(String[] args) {
		List<Students> s = new ArrayList<>();
		
		Students s1 = new Students(1,"Ram",12);
		Students s2 = new Students(2,"Siva",11);
		Students s3 = new Students(3,"Ravi",13);
		
		s.add(s1);
		s.add(s2);
		s.add(s3);
		
		for(Students list : s) {
			System.out.println(list.id+" "+list.name+" "+list.age);
		}

	}
	
	

}
class Students{
	int id;
	String name;
	int age;
	
	public Students(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
}
