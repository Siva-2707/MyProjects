
public class Cuboid {
	private static int idGenarator=1;
	private int cuboidId;
	private int length;
	private int width;
	private int height;
	
	public Cuboid( int length, int width, int height) {
		super();
		this.cuboidId = idGenarator++;
		this.length = length;
		this.width = width;
		this.height = height;
	}

	

	public int getCuboidId() {
		return cuboidId;
	}

	public void setCuboidId(int cuboidId) {
		this.cuboidId = cuboidId;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
	public double getSurfaceArea() {
		double totalSurfaceArea= 2*((length*width)+(width*height)+(length*height));
		return totalSurfaceArea;
	}
	public double getVolume() {
		double volumeCuboid= length*width*height;
		return volumeCuboid;
	}
	public double getVolume(double hollowRadius) {
		double volumeCuboid=length*width*height;
		double volumeSphere=4*(Math.PI*(3*hollowRadius))/3;
		double finalVolumeCuboid=volumeCuboid-volumeSphere;
		return finalVolumeCuboid;
	}
	
	
}
