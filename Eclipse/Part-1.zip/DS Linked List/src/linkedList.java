class Node{
	public int data;
	public Node next;
}
class list{
	Node head;
	
	
	public void insert(int data){
		Node node= new Node();
		node.data = data;
		node.next = null;
		
		if(head==null) {
			head=node;
		}
		else {
			Node n = head;
			while(n.next!=null) {
				n = n.next;
			} 
			n.next = node;
		}
	}
	
	
	public void insertAtStart(int data) {
		Node node = new Node();
		node.next = head;
		head = node;
		node.data=data;
	}
	
	
	public void insertAtLast(int data) {
		Node n = new Node();
		n.data = data;
		n.next = null;
		Node node = head;
		while(node.next!=null) {
			node = node.next;
		}
		node.next = n;
		
	}
	
	public void insertAt(int index, int data) {
		
		if(index==0) {
			insertAtStart(data);
		}
		else {
			Node n = new Node();
			n.data = data;
			n.next = null;
			
			Node node = head;
			for(int i=0;i<index-1;i++) {
				node = node.next;
			}
			n.next = node.next;
			node.next = n;
		}
		
	}
	
	public void deleteAt(int index) {
		
		if(index == 0) {
			head = head.next;
		}
		else {
			Node node = head;
			Node n1 = null;
		for(int i=0;i<index-1;i++) {
			node = node.next;
		}
		n1 = node.next;
		node.next = n1.next;
		
		}
				
	}
	
	public int show() {
		if(head==null) {
			System.out.println("No value in the list");
			return 0;
		}
		Node node = head;
		while(node.next!=null) {
			System.out.println(node.data);
			node = node.next;
		}
			System.out.println(node.data);
			return 0;
	}
	
	
}
public class linkedList{

	public static void main(String[] args) {
		list l = new list();
		l.insert(34);
		l.insertAtLast(89);
		l.insertAtStart(51);
		l.insertAt(0, 78);
		l.deleteAt(2);
		l.show();
		
		
	}

}
