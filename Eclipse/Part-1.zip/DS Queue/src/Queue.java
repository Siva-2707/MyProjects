
public class Queue {
	
	int queue [] = new int [5];
	int first = 0 , last = 0 , size=0;
	
	public void enQueue(int data) {
		queue[last%5] = data;
		last++;
		size++;
	}
	
	public int deQueue() {
		int data = queue[first%5];
		first++;
		size--;
		return data;
	}
	
	public void show() {
		System.out.print("Elements : ");
		for(int i=0; i<size; i++) {
			System.out.print(queue[(first+i)%5]+" ");
		}
		System.out.println();
	}
	
	public boolean isEmpty() {
		return last==0 ? true : false ;
	}
	
}
