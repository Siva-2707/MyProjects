
public class Runner {

	public static void main(String[] args) {
		
		Queue q = new Queue();
		System.out.println(q.isEmpty());
		q.enQueue(1);
		q.enQueue(2);
		
		q.show();
		q.enQueue(3);
		q.enQueue(4);
		q.show();
		q.deQueue();
		q.show();
		q.deQueue();
		q.show();
		q.deQueue();
		q.show();
		System.out.println(q.isEmpty());
		q.enQueue(12);
		q.show();
		q.enQueue(13);
		q.show();
		q.enQueue(14);
		q.show();
		q.enQueue(15);
		q.show();
		q.enQueue(16);
		q.show();

	}

}
