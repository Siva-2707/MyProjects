
public class DynamicStack {
	int capacity = 2;
	int stack[] = new int[2];
	int top=0;
	
	public void push(int data) {
		
		if(size()==capacity)
			expand();
			stack[top++]=data;
	}
	
	private void expand() {
		int length = size();
		int newStack[] = new int [capacity*2];
		System.arraycopy(stack, 0, newStack, 0, length);
		capacity*= 2;
		stack = newStack;
		
		
	}
	
	public int pop() {
		int data = 0;
		if(isEmpty())
			System.out.println("Stack is Empty");
		else {
			data = stack[--top];
			stack[top]= 0;
		}
		
		if(size() <= (capacity/2)/2)
			shrink();
		
		return data; 
	}
	
	private void shrink() {
		int length = size();
		int newStack[] = new int [capacity/2];
		System.arraycopy(stack, 0, newStack, 0, length);
		capacity/= 2;
		stack = newStack;
	}
	
	public void peek() {
		System.out.println(stack[top-1]);
	}
	
	public int size() {
		return top;
	}
	
	public boolean isEmpty() {
		return top<=0 ? true : false ;
	}
	
	public boolean isFull() {
		return top==5 ? true : false ;
	}
	
	public void show() {
		for(int s : stack )
			System.out.print(s+" ");
		System.out.println();
	}
	

}
