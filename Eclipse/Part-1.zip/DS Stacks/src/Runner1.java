
public class Runner1 {

	public static void main(String[] args) {
		Stack s = new Stack();
		s.push(1);
		s.push(34);
		s.pop();
		s.push(25);
		s.push(32);
		s.pop();
		s.push(35);
		s.push(56);
		s.push(78);
		s.peek();
		s.size();
		s.show();
		System.out.println("Empty = "+s.isEmpty());
		s.pop();
		s.pop();
		s.pop();
		s.pop();
		s.pop();
		s.pop();
		System.out.println(s.isEmpty());
		s.show();
		
		

	}

}
