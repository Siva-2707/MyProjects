
public class Runner2 {

	public static void main(String[] args) {
		
		DynamicStack ds = new DynamicStack();
		ds.push(12);
		ds.show();
		ds.push(12);
		ds.show();
		ds.push(12);
		ds.show();
		ds.push(12);
		ds.show();
		ds.push(12);
		ds.show();
		ds.push(12);
		ds.show();
		ds.pop();
		ds.show();

		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.pop();
		ds.show();
		ds.push(87);
		ds.show();
		ds.push(87);
		ds.show();
		ds.push(87);
		ds.show();
		ds.push(87);
		ds.show();

	}

}
