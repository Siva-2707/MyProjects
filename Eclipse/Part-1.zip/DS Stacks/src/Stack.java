
public class Stack {
	int stack[] = new int[5];
	int top=0;
	
	public void push(int data) {
		if(isFull())
			System.out.println("Stack is full");
		else
			stack[top++]=data;
	}
	
	public void pop() {
		if(isEmpty())
			System.out.println("Stack is Empty");
		else {
			int data = stack[--top];
			stack[top]= 0;
			System.out.println(data);
		}
	}
	
	public void peek() {
		System.out.println(stack[top-1]);
	}
	
	public void size() {
		System.out.println("Size is: "+top);
	}
	
	public boolean isEmpty() {
		return top<=0 ? true : false ;
	}
	
	public boolean isFull() {
		return top==5 ? true : false ;
	}
	
	public void show() {
		for(int s : stack )
			System.out.print(s+" ");
		System.out.println();
	}
	

}
