
public class Main {

	public static void main(String[] args) {
	
		Car car1 = new Car("Mustang",2021,9999.9);
		System.out.println(car1.getModel());
		System.out.println(car1.getYear());
		System.out.println(car1.getPrice());
		
		car1.setPrice(2000);
		System.out.println("After changing price using setter. ");
		System.out.println(car1.getModel());
		System.out.println(car1.getYear());
		System.out.println(car1.getPrice());
		

	}

}
