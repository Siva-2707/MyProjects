
public class BankAccount {

	private int accountNumber;
	private int accountBalance;
	
	public BankAccount(int accountNumber, int accountBalance) {
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
	System.out.println("Account has been created");
	}
	
	public void deposit(int addMoney) {
		if(addMoney <= 0)
			System.out.println("You cannot deposite a negative amount");
		else {
			this.accountBalance += addMoney;
			System.out.println("$"+addMoney+"is added to "+this.accountNumber+".");
		}
	}
	
	public void withdraw(int removeMoney) {
		if(removeMoney > this.accountBalance)
			System.out.println("Insufficient Balance");
		else {
			this.accountBalance -= removeMoney;
			System.out.println("$"+removeMoney+"is been withdrawn from " + this.accountNumber+".");
		}
			
	}
	
	public int getAccountBalance() {
		return this.accountBalance;
	}
	
	public int getAccountNumber() {
		return this.accountNumber;
	}
}
