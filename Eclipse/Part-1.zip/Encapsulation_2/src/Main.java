
public class Main {

	public static void main(String[] args) {
		
		BankAccount myBankAccount = new BankAccount(4141,100);
		
		System.out.println("Account Number : "+myBankAccount.getAccountNumber());
		System.out.println("Account Balance : "+myBankAccount.getAccountBalance());
		myBankAccount.deposit(200);
		myBankAccount.deposit(0);
		myBankAccount.withdraw(100);
		System.out.println("Account Balance : "+myBankAccount.getAccountBalance());
		myBankAccount.withdraw(500);
	}

}
