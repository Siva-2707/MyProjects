
public class MultipleCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
//			int k=5/0;
//			int k[]=null;
//			System.out.println(k[1]);
			int a = Integer.parseInt("Abc");
			int j[]=new int[]{1,2,3,4};
			System.out.println(j[5]);
		}
		catch(ArithmeticException e) {
			System.err.println("Cannot divide by Zero");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("Limit exceeded");
		}
		catch(Exception e) { // This should be declared in the last coz we have already declared the sub class of Exception class below.
			System.out.println(e);
		}
		finally {
			System.out.println("Bye");
		}
		
		try {
			int a=6/0;
			
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException e) { // for same messege to be printed.
			System.out.println("Error");
		}
		System.out.println("Remaing code");
		
	}

}
