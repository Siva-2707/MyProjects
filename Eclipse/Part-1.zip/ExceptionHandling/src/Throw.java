
public class Throw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=16;
		if(age<18) {
			throw new ArithmeticException("Not elegible for voting");
		}
		else {
			System.out.println("Welcome to voting");
		}
		try {
			int k=5;
		}
		catch(ArithmeticException e) {
			throw new ArithmeticException("Arithmetic Exception");
		}
		System.out.println("Remaing code");
		
	}
	

}
