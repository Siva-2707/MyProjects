import java.io.BufferedReader;
import java.io.InputStreamReader;

class Throws{
	public static void main(String args[])throws Exception { // This handles only checked exceptions.
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a number: ");
		int n = Integer.parseInt(br.readLine());  // This line may throw IOException. So, its handled by Throws Exception.
		
		System.out.println(n);
		System.out.println("End");
		
		CheckedTry ob = new CheckedTry();
		
		ob.method(br);
		TryWithResourse.method2();
		}
		
	
	}
class CheckedTry{ // Handeling checked exception using Try Catch methods.
	
	public  void method(BufferedReader br) throws Exception {
		int n;
		System.out.println("Enter Number 2: ");
		try {
			n = Integer.parseInt(br.readLine());
			System.out.println(n);
		}
		catch(Exception e) {
			System.out.println(e);
		}
//		finally {
//			br.close();  // This will throw an IOException. 
//			
//		}
	}
	
}

class TryWithResourse{ // This enables to declare the resource within the try method. So no need for catch or finally method.
	
	public static void method2() throws Exception {
		// No need for catch or finally block when using try with resources. 
		try(BufferedReader sc = new BufferedReader(new InputStreamReader(System.in))){ // Here resource closes automatically.
			System.out.println("Enterining 3rd Number :");
			int n=Integer.parseInt(sc.readLine());
			System.out.println(n);
		}
		
	}
}