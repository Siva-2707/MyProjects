
public class TryCatchFinally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println(5/0);  // If this statement is not in try block there may be an exception arising.
										//And thus the statements following this statement is not executed. 
		}
		catch(ArithmeticException e) {
			System.err.println("Red Error");
		}
//		System.out.println(); //There shouln't be any statements between try catch and finally blocks.
		try {
			String s =null;
			System.out.println(s.length());
		}
		finally {  // This block gets executed whether there is an exception or not and whether the exception is handled or not.
			System.exit(0);
			System.out.println("Bye");
		}
	}
	

}
