
public class UserDefinedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int i=0;
		int j=1;
		try {
		int k= i/j;
		
		if(k==0)
			throw new ExceptionSiva("null value");
		System.out.println(k);
		}
		catch(ExceptionSiva e) {
			System.out.println("Error "+e.getMessage());
		}
		
	}

}

class ExceptionSiva extends Exception{  // user defined Exception class.
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionSiva(String s) {  // constructor
		super(s);
	}
}
