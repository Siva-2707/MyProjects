import java.util.*;
public class Main {
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int capacity = sc.nextInt();
		int stops = sc.nextInt();
		sc.nextLine();
		List<String> list = new ArrayList<>();
		for(int i=0;i<stops;i++) {
		list.add(sc.nextLine());
		}
		
		String query = sc.nextLine();
		BusProb obj1 = new BusProb();
		String str = obj1.output(capacity, stops, list, query);
		System.out.println(str);
		sc.close();
	}

}
class Passanger
{
    int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getFare() {
        return fare;
    }

    public void setFare(float fare) {
        this.fare = fare;
    }
    float fare;
    public Passanger(int id, float fare)
    {
        this.id=id;
        this.fare=fare;
    }
}
class BusProb extends Main {
   
    public String output(int capacity, int stops, List<String> listOfInputStrings, String query)
    {
    	int arr[][] = new int[stops][];
        for(int i=0;i<stops;i++) {
        	String sp[] = listOfInputStrings.get(i).split(" ");
        	int n =sp.length;
        	arr[i]= new int[n];
        	for(int j=0;j<n;j++) {
        		arr[i][j] = Integer.parseInt(sp[j]);
        	}
        }
        
    	
    	String queryArr[] = query.split("[, ]");
    	int a = Integer.parseInt(queryArr[0]);
    	return query1(a,arr, capacity);
    	
    		
    	
        
    }
    public static String query1(int choice, int arr[][], int capacity) {
    	int in=0,out=0;
    	int a=0,b=0,c=0;
    	double percentage=0;
    	for(int i=0;i<arr.length;i++) {
    		double tempIn=0, tempOut=0;
    		for(int j=0;j<arr[i].length;j++) {
    			if(arr[i][j]<0) 
    				tempOut++;
    			else
    				tempIn++;
    			
    		}
    		in+=tempIn;
        	out+=tempOut;
        
    		percentage = ((in-out)/(double)capacity)*100;
//    		System.out.println("Percentage: "+percentage);
    		if(percentage<=25)
    			a+=tempIn;
    		else if(percentage<=50)
    			b+=tempIn;
    		else
    			c+=tempIn;
    				
    	}
    	
    	String str1 = "number of passangers who got on the bus :"+in+", number of passangers who got off the bus : "+out;
    	double n = capacity;
    	String str = a+" passengers travelled with a fair of "+(n+(n*0.6))+", "+b+" passengers travelled with a fair of "+(n+(n*0.3))+", "+c+" passengers travelled with a fair of "+n;
    	if(choice==1)
    	return str1;
    	else if(choice==2)
    	return str;
    	
    	return null;
    }
   
}

