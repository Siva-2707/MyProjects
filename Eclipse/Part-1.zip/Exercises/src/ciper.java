
public class ciper {

	public static void main(String[] args) {
		String str = "Hello world ?";
		
		String cipered = cipered(str);
		
		System.out.println(cipered);
		
		System.out.println(diciper(cipered));
		
	}
	
	public static String caseChange(String str) {
		
		char arr[] = str.toCharArray();
		for(int i=0;i<str.length();i++) {
			if(Character.isUpperCase(arr[i]))
				arr[i]+=32;
			else if(Character.isLowerCase(arr[i]))
				arr[i]-=32;
		}
		
		return new String(arr);
		
	}
	
	public static String cipered(String normal) {
		normal = caseChange(normal);
		StringBuffer sb =  new StringBuffer(normal);
		sb.reverse();
		normal = sb.toString();
		normal = normal.replace(' ', '*');
		sb.delete(0, sb.length());
		char arr[]= normal.toCharArray();
		for(int i=0;i<normal.length();i++) {
			if(i%2!=0) {
				sb.append((int)arr[i]);
			}
			else
				sb.append(arr[i]);
		}
		sb.append(3);
		normal = sb.toString();
		return normal;
	}
	
	public static String diciper(String cipered) {
		cipered = cipered.substring(0,cipered.length()-1);
		char arr[] = cipered.toCharArray();
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<cipered.length();i++) {
				
				if(Character.isDigit(arr[i])){
					StringBuffer digit = new StringBuffer();
					while(Character.isDigit(arr[i])){
						digit.append(arr[i]);
						if(i==cipered.length()-1)
							break;
						i++;
					}
					if(Character.isAlphabetic(arr[i]))
						i--;
			
					
					int n = Integer.parseInt(digit.toString());
					sb.append((char)n);
				}
				else 
					sb.append(arr[i]);
				
		}
		sb.reverse();
		cipered = sb.toString();
		cipered = cipered.replace('*',' ');
		cipered = caseChange(cipered);
		return cipered;
	}
	
	
	

}
