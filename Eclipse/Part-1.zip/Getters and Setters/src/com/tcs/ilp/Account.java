package com.tcs.ilp;

public class Account {
	private int accountNumber;
	private String accountHolderName;
	private double balance;
	private String type;
	
	Account(int accountNumber,String accountHolderName,double balance, String type){ //Parameterized Constructor (Values are passed as parameters)
		this.accountNumber=accountNumber;
		this.accountHolderName=accountHolderName;
		this.balance=balance;
		this.type=type;
	}
	
public void setAccountNumber(int accountNumber) {
	this.accountNumber=accountNumber;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName=accountHolderName;
}
public void setBalance(double balance) {
	this.balance=balance;
}
public void setType(String type) {
	this.type=type;
}

	
public int getAccountNumber() {
	return accountNumber;
}
public String getAccountHolderName() {
	return accountHolderName;
}
public double getBalance() {
	return balance;
}
public String getType() {
	return type;
}


}
