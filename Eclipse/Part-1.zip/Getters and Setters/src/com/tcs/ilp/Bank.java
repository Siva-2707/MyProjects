package com.tcs.ilp;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account account1= new Account(1,"Shree",2000,"Current");
		Account account2= new Account(2,"Rama",1000,"Savings");//Parameterized Constructor
		
		account1.setBalance(2500);
		account1.setAccountHolderName("Siva");
		
		System.out.println("Account no: "+account1.getAccountNumber());
		System.out.println("Account Holder Name: "+account1.getAccountHolderName());
		System.out.println("Account Balance: "+account1.getBalance());
		System.out.println("Account type: "+account1.getType());
		
		System.out.println();
		
		System.out.println("Account no: "+account2.getAccountNumber());
		System.out.println("Account Holder Name: "+account2.getAccountHolderName());
		System.out.println("Account Balance: "+account2.getBalance());
		System.out.println("Account type: "+account2.getType());
		

	}

}
