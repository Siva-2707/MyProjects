public class Parent {
	String parentName="Ravi";
	String parentNumber="7708879788";
	int parentId;

	void setParentsId(int id) {
		this.parentId=id;
	}
	

}
