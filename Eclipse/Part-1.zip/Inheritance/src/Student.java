public class Student extends Teacher {
	static int id=1;
	public static void main(String ar[]) {
		Student s1=new Student();
		int studetId=s1.getId();
		s1.setParentsId(studetId);
		System.out.println("Student ID :"+studetId);
		System.out.println("Parents ID :"+s1.parentId);
		System.out.println(s1.collegeName);
		System.out.println(s1.designation);
		
		Student s2=new Student();
		System.out.println(s2.getId());
		
		s1.does();
		
	}
	
	public int getId(){
		return id++;
	}
}
