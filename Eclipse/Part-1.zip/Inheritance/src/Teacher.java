
public class Teacher extends Parent{
	String designation="Teacher";
	String collegeName="SMVEC";
	void does() {
		System.out.println("Teaching");
	}
}
