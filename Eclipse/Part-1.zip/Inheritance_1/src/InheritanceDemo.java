class Calculator{
	public int add(int a,int b) {
	return a+b;
	}
}
class advCalculator extends Calculator{
	
	public int sub(int a,int b) {
		return a-b;
	}
}
class veryAdvCalculator extends advCalculator{ // This has access to advCalculator class 
	public int multi(int a, int b) {			// and Calculator class (Since advCalculator extends 
		return a*b;								//                      Calculator class.
	}
}


public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		veryAdvCalculator cal = new veryAdvCalculator();
		System.out.println(cal.multi(2,4));
		System.out.println(cal.add(1, 45));
		System.out.println(cal.sub(45, 20));
	}

}
