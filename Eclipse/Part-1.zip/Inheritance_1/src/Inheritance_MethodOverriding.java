class Insect {
	int age;
	int numberOfLegs;
	
	public Insect(int age, int numberOfLegs){
		this.age = age;
		this.numberOfLegs = numberOfLegs;
	}
	
	public void says() {
		System.out.println("...");
	}
	public void crawl() {
		System.out.println("The insect crawled");
	}
	
}

class Spider extends Insect {

	boolean isPoisonous;
	
	public Spider(int age, boolean isPoisonous) {
		super(age, 8);
		this.isPoisonous = isPoisonous;
	}
	public void says() {
		System.out.println("HISSSS");
	}
}


 class Bug extends Insect{
double length;

public Bug(int age, double length) {
	super(age,2);
	this.length = length;
}
public void says() {
	System.out.println("CHIRP");
}
public void jump() {
	System.out.println("Bug jumped");
}
}


public class Inheritance_MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Insect insect = new Insect(5,6);
		Spider spider = new Spider(13,true);
		Bug bug = new Bug(2,2.5);
		
		insect.crawl();
		insect.says();
		spider.crawl(); // There is no crawl method inside Spider and Bug.
		spider.says();    // It inherits from Insect class.
		bug.crawl();   
		bug.says();
		
		
		// There is says method in each class including Insect class, 
		//So it overrides the parent class method with its own method.
	}

}
