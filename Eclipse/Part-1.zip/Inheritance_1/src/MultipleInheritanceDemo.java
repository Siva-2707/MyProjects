class P{
	public void show() {
		System.out.println("In P");
	}
}
class Q{
	public void show() {
		System.out.println("In Q");
	}
}
//class R extends P , Q{ Here an error occurs. Multiple inheritance is not possible in java 
//	                     since it causes ambiguity error.
//						 Here there are two show() methods in P and Q the compiler doesn't know 
//} 					 which to call. So ambiguity occurs.	
public class MultipleInheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//	R obj = new R();
		// obj.show();
	}

}
