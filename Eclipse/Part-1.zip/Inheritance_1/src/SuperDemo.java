class A{
	A(){
		System.out.println("In A");
	}
	A(int i){
		System.out.println("In int A");
	}
}
class B extends A{
	B(){
		//super(); //every constructor has a super statement which calls the constructor of parent class.
		System.out.println("In B");
	}
	B(int i){
		super(i);  //values can be passed in super statement to call the parameterized parent constructor. 
		System.out.println("In int B");
	}
}
public class SuperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B obj = new B(5);
		B obj1 = new B();
		
	}

}
