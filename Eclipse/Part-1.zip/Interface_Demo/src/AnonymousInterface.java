interface abc{
	void show();
}

public class AnonymousInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		abc ob = new abc() { // This is interface implementation process, no need for creating a class for implementing it.
			public void show() {   //Instead of creating a class and then accessing it, we can use this anonymous class.
				System.out.println("ANYTHING");
			}
		};
		ob.show();
		ob.show();
	}

}
