@FunctionalInterface //-> This interface has more than one method, by has only one abstract method. So, its a functional interface.
interface Eg{
	void show(); // Abstract method
	default void defaultMethod() {				//From JAVA 1.8 Interface can have method definition, by making the method default.
		System.out.println("In default method");
	}
}

class implementer implements Eg{
public void show(){
	System.out.println("In show");
	}
}
public class DefaultMethodInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// We cannot instantiate an interface, so a class is created that implements the interface.
		
		implementer i = new implementer();
		i.show();
		i.defaultMethod();
	}
	

}
