/* Types of interface
 * 
 * 1. Normal - Can have more than one method.
 * 2. Single Abstract Method (SAM) - Can have only one abstract method. This is called as functional interface from JAVA 8.
 * 3. Marker Interface - Does not have any method.
 * 
 */

@FunctionalInterface
interface def{
	void show();
}

public class Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		def obj = new def() {
			public void show() {
				System.out.println("Anything");
			}
		};
		obj.show();
		// Lambda expressions can be achieved only in Functional interface, coz if there is more than one method it causes confusion.
		def obj1 = () -> {
			System.out.println("First line");
			System.out.println("Second line");
		};
		obj1.show();
		System.out.println();
		def obj2 = () -> System.out.println("Single line lambda function");
		obj2.show();
	}

}
