interface Pet{
	void play();  // All the methods declared in the interface must be present in the implemented class
	void eat();			  //All methods inside Interface are abstract methods, so only declaration of method is allowed, method cannot be defined
							
						
	//	public void eat() {
//		
//	}
}				 //	
class Dog implements Pet{
	public void play(){
		System.out.println("The dog plays with its owner");	
	}
	public void eat() {
		System.out.println("Eating");
}
}
class Cat extends Dog implements Pet {
	public void play() {
		System.out.println("The cat plays around the street");
	}
}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pet dog = new Dog();
		Pet cat = new Cat();
		if( dog instanceof Pet) {
			System.out.println("Dog is a pet");
			dog.play(); 
			dog.eat();
		}
		if( cat instanceof Pet) {
			System.out.println("Cat is a pet");
			cat.play();
			cat.eat(); // Inherits from dog class.
		}
		
	}

}
