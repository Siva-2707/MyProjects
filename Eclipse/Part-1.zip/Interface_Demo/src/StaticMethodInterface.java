interface staticEg{
	
	int num=2; // We can also create variables inside the interface but it is of Final type (i.e) Constant.
	void show(); // Abstract method declaration 
	default void inStaticEg() {
		System.out.println("Inside default method");  // Interfaces cannot be instantiated so, inorder to access InStatic Method, a class has to be created.
	}										// To overcome this from JAVA 1.8 methods can be declared as Static inside Interface.
	static void staticMethod() {
		System.out.println("Inside static method");
		System.out.println(num); // Using num
	}
}

public class StaticMethodInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		staticEg.staticMethod(); // The static method inside the interface can be accessed by using the interface name.
		System.out.println(staticEg.num); // Using num by interface name.
	}

}
