
public class CustomerUtil {

	public static boolean checkCustomerExistance(customer c[],String name) {
		boolean exist=false;
		for(customer cust:c) {
			if(cust.getCustomerName().equals(name)) {
				exist=true;
				return exist;
			}
		}
		return exist;
	}
	
	public static int getCountOfAccount(customer c[],String name) {
		int count=0;
		for(customer cust:c) {
			if(cust.getCustomerName().equals(name))
				count++;
			
		}
		return count;
	}
	
	public static int updateCustomerId(customer c[],int id,int updateId) {
		for(customer cust:c) {
			if(cust.getCustomerId()==id) {
				cust.setCustomerId(updateId);
				return 1;
			}
		}
		return 0;
	}
	
	public static int[] getAccounts(customer c[], String name){
		int accountArray[]=new int[10];
		int k=0;
		for(customer cust:c) {
			if(cust.getCustomerName().equals(name)) {
				accountArray[k]=cust.getAccountNumber();
				k++;
			}
		}
		return accountArray;
	}
}
