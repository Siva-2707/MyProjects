//import java.util.*;
public class Main {

	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in);
		customer cust[]=new customer[5];
		/*for(int i=0;i<5;i++) {
			int customerId=sc.nextInt();
			String customerName=sc.next();
			String customerAddress=sc.next();
			int customerNumber=sc.nextInt();
			int accountNumber=sc.nextInt();
			String accountType=sc.next();
			cust[i]=new customer(customerId,customerName,customerAddress,customerNumber,accountNumber,accountType);
		}*/
		
		cust[0]=new customer(1,"Sachin","ABC",0123,123456789,"Savings");
		cust[1]=new customer(2,"Ravi","ASD",0345,213254346,"Current");
		cust[2]=new customer(3,"Ram","KJY",0231,21353356,"Current");
		cust[3]=new customer(4,"Siva","AHD",0345,257474346,"Savings");
		cust[4]=new customer(5,"Shree","DMG",4535,2145673466,"Savings");
		
		System.out.println("Cusomer Sachin exist is "+CustomerUtil.checkCustomerExistance(cust,"Sachin"));
		System.out.println("No. of accounts Sachin has: "+CustomerUtil.getCountOfAccount(cust, "Sachin"));
		
		int status=CustomerUtil.updateCustomerId(cust, 1, 6);
		if(status!=0) 
			System.out.println("Customer id updated from 1 to 6");
		int [] account=CustomerUtil.getAccounts(cust, "Sachin");
		System.out.println("Account numer of Sachin are:" );
		for(int i=0;i<account.length;i++) {
			if(account[i]!=0)
				System.out.println(account[i]);
		}
		
		
	}

}
