
public class customer {
private int customerId;
private String customerName;
private String customerAddress;
private int contactNumber;
private int accountNumber;
private String accountType;

public customer(int customerId, String customerName, String customerAddress, int contactNumber, int accountNumber,
		String accountType) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerAddress = customerAddress;
	this.contactNumber = contactNumber;
	this.accountNumber = accountNumber;
	this.accountType = accountType;
}


public int getCustomerId() {
	return customerId;
}

public String getCustomerName() {
	return customerName;
}

public String getCustomerAddress() {
	return customerAddress;
}

public int getContactNumber() {
	return contactNumber;
}

public int getAccountNumber() {
	return accountNumber;
}

public String getAccountType() {
	return accountType;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}

public void setContactNumber(int contactNumber) {
	this.contactNumber = contactNumber;
}

public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}



}
