// Classes without names are called Anonymous class.
// Anonymous Class are used when their need is of only overriding a method
class D{
	void show() {
		System.out.println("In D");
	}
}
class E extends D{
	void show() {
		System.out.println("In E");
	}
}
class F extends E{
	void show() {
		System.out.println("In F");
	}
}

public class AnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D obj = new D(); // Instantiating class D
		obj.show();    // Accessing show method with the help of the instance created for the class.
		E objj = new E();
		objj.show();   // This overrides the method present  in the Parent class.
		// When there is class just used for only overriding a method in parent class, anonymous classes are used.
		F obj1 = new F() {
			void show() {
				System.out.println("In G");
			}
		};
		obj1.show(); // This directly calls the show method in the anonymous class. 
	}

}
