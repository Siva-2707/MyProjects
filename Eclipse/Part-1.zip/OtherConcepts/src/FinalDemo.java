final class A{       //Final class cannot be extended(i.e) Inheritance is not possible in Final class 
	final int i=0;
	final double PI = 3.14; // 'i' value cannot be changed, it acts as constant
	public A() {
//		i=10; //-> This will cause error.
	}
	
}
 class B{
	 public final void show() {		// By making a method final, overriding is disabled in child class.
		 System.out.println("In B");
	}
}
 class C extends B{
//	 public void show() {
//			System.out.println("In C");     // Overriding method in childClass 
//		}
 }
public class FinalDemo {

	public static void main(String[] args) {
			C obj = new C();
			obj.show();
	}

}
