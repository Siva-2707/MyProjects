class Outer{
	int a;
	public void show() {
		System.out.println("In outer class method");
	}
	
	 class Inner{                    //The class can be defined as Static also, 
		public void display() {     //if so no object creation is requried
			System.out.println("In inner class method");
		}
	}
	
	
}
public class InnerClassDemo {

	public static void main(String[] args) {
	
		Outer obj = new Outer();
		obj.show();
		
		Outer.Inner obj2 = obj.new Inner(); // Syntax for creating object for an inner class
		obj2.display(); //For non-static class
//		Outer.Inner.display();   // For static class
		
		
	}

}
