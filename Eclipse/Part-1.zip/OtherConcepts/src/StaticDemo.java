class Employee{
	int id;
	int salary;
	static String ceo;
	
	static {
		ceo = "Vishnu";
		System.out.println("In static block 2"); 
	}
	
	static {
		ceo = "Raj";
		System.out.println("In static block 1"); 
	}
	
	
	// Static block is executed before constructor and only once.
	
	
	public Employee() { // Default constructor
		id=1;
		salary=2000;
	}
	
	public void show() {
		System.out.println(id+"  "+salary+"  "+ceo);
	}
	
	
}



public class StaticDemo {
	
	 static int a;

	public static void main(String[] args) {
	
		Employee rajesh =new Employee();
		rajesh.id=2;
		rajesh.salary=5000;
		Employee suresh = new Employee();
		Employee.ceo = "Siva";
		rajesh.show();
		suresh.show();
		a=2;
		

	}

}
