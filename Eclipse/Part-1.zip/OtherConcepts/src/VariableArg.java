class Calculator{
	
	public int add(int...i) { // Variable length argument.
		int sum=0;
		for(int n:i)
			sum+=n;
		return sum;
	}
}

public class VariableArg{

	public static void main(String[] args) {
		
		Calculator c1 = new Calculator();
		int result = c1.add(1,2,3,4,5,6);
		System.out.println(result);

	}

}
