
public class WrapperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5; //Primitive Datatype
		Integer j = new Integer(5); //Wrapper Class
		System.out.println(i+j);
		
		//Wrapper Class keywords -> Integer Float Byte Short Long Double Boolean Character 
		
		Integer k = new Integer(i); // -> Wrapping or Boxing (Putting a variable into an object)
		int l = k.intValue(); // -> Unboxing or UnWrappring (Fetching value from object and storing it into a variable)
		
		Integer value = k; // AutoBoxing or AutoWrapping  
		int m = value; // AutoUnBoxing or AutoUnWrapping
		
		//Primitive datatypes are faster when program execution
		// Certain frameworks only supports WrapperClasses so then, WrapperClasses are used.
		
		String str = "123";
//		int n = str; -> Not possible
		int n = Integer.parseInt(str); // Here parseInt Method converts String value to int. 
	}									// But its a Static method, hence Class name (Integer) is used to access it.

}
