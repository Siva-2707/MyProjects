public class TestSort {

	public static void main(String args[]) {
		Student s1=new Student(1,"John",75.3);
		Student s2=new Student(2,"Adm",60);
		Student s3=new Student(3,"Rachel",79.9);
		Student s4=new Student(4,"Dylan",52);
		Student s5=new Student(5, "Jamie",81.9);
		
		Student s[]=new Student[] {s1,s2,s3,s4,s5};
		sort(s);
		
		for(int i=0;i<s.length;i++) {
			//System.out.println("Student Id: "+s[i].getStudentId());
			System.out.println("Student Name: "+s[i].getStudentName());
			//System.out.println("Student Marks: "+s[i].getMarks());
			System.out.println();
		}
		
		
	}
	public static void sort(Student s[]) {
		Student temp;
		for(int i=0;i<s.length;i++) {
			for(int j=i+1;j<s.length;j++) {
				if(s[i].getMarks()<s[j].getMarks()) {
					temp=s[i];
					s[i]=s[j];
					s[j]=temp;
				}
			}
		}
	}
}

class Student {
	
private int studentId;
private String studentName;
private double marks;
public Student(int studentId, String studentName, double marks) {
	super();
	this.studentId = studentId;
	this.studentName = studentName;
	this.marks = marks;
}
public int getStudentId() {
	return studentId;
}
public String getStudentName() {
	return studentName;
}
public double getMarks() {
	return marks;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public void setMarks(double marks) {
	this.marks = marks;
}

}

