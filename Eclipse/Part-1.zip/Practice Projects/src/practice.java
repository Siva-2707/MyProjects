import java.util.*;
class practice{
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int k=0;
		int arr[]=new int[n];
		for(int i=2;i<10;i++)
			if(n%i==0)
				arr[k++]=i;
		if(k==0) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
//		for(int i=0;i<k;i++)
//			System.out.println(arr[i]);
		
		int temp=n,digit=0;
		while(temp>0) {
			digit++;
			temp/=10;
		}
//		System.out.println(digit);
		int min=n*n;
		
		for(int a=0;a<k;a++) {
			if(digit>=2)
				for(int b=0;b<k;b++) {
					int sum=arr[a]*10+arr[b];
					if(arr[a]*arr[b]==n&&sum<min)
						min=sum;
					if(digit>=3)
						for(int c=0;c<k;c++) {
							sum=arr[a]*100+arr[b]*10+arr[c];
							if(arr[a]*arr[b]*arr[c]==n&&sum<min)
								min=sum;
							if(digit>=4)
								for(int d=0;d<k;d++) {
									sum=arr[a]*1000+arr[b]*100+arr[c]*10+arr[d];
									if(arr[a]*arr[b]*arr[c]*arr[d]==n&&sum<min)
										min=sum;
									if(digit>=5)
										for(int e=0;e<k;e++) {
											sum=arr[a]*10000+arr[b]*1000+arr[c]*100+arr[d]*10+arr[e];
											if(arr[a]*arr[b]*arr[c]*arr[d]*arr[e]==n&&sum<min)
												min=sum;
										}
								}
								
						}
				}
			
		}
		System.out.println(min);
		
	}
}