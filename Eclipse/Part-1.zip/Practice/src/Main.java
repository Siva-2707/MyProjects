import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the pen details");
		System.out.println("Model Number: ");
		int modelNumber=sc.nextInt();
		System.out.println("Choose pen color: 1.Red 2.Green 3.Blue");
		int colorOption=sc.nextInt();
		System.out.println("Choose Pen Type: 1. InkPen 2.BallPen 3.CatrigePen");
		int typeOption=sc.nextInt();
		
		Pen p1 = new Pen(modelNumber,colorOption,typeOption);
		
		System.out.println("Your Pen Specifications");
		System.out.println("Model Number:"+p1.getModelNumber());
		System.out.println("Pen Color:"+p1.getPenColor());
		System.out.println("Pen Type:"+p1.getPenType());
		
		
	}

}
