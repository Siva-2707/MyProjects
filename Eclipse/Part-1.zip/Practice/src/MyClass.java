import java.util.*;
public class MyClass {

    public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	String str1=s.next();
	String str2=s.next();
	
	
	for(int i=0;i<str1.length();i++){
	    for(int j=i+1;j<str1.length();j++){
	        if(str1.charAt(i)==str1.charAt(j))
	        str1.replace(str1.charAt(j),' ');
	    }
	    
	}
	String arr[]=str1.split("");
	
	for(int i=0;i<str2.length();i++){
	    for(int j=i+1;j<str2.length();j++){
	        if(str1.charAt(i)==str2.charAt(j))
	        str1.replace(str2.charAt(j),' ');
	    }
	    
	}
	int count=0;
	for(int i=0;i<str1.length();i++){
	    if(str2.contains(arr[i])){
	    count++;
	    }
	}
System.out.println(count);
	}
}