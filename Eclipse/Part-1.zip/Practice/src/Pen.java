import java.awt.*;
public class Pen {

	private int modelNumber;
	private Color penColor;
	private String penType;
	
	Pen(int modelNumber,int colorOption,int typeOption){
		this.modelNumber=modelNumber;
		switch(colorOption)
		{
		case 1:this.penColor=Color.red;
		break;
		case 2:this.penColor=Color.green;
		break;
		case 3:this.penColor=Color.blue;
		break;
		}
		switch(typeOption)
		{
		case 1:this.penType="InkPen";
		break;
		case 2:this.penType="BallPen";
		break;
		case 3:this.penType="CatrigePen";
		break;
		}
	}
	
	public int getModelNumber() {
		return modelNumber;
	}
	public Color getPenColor() {
		return penColor;
	}
	public String getPenType() {
		return penType;
	}
	/*
	 * public void setModelNumber(int modelNumber) { this.modelNumber=modelNumber; }
	 * public void setColor(Color penColor){ this.penColor=penColor; } public void
	 * setType(String penType) { this.penType=penType; }
	 */
}
