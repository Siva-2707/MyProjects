import java.util.*;
import java.lang.*;

public class Rough{

    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        Package[] c = new Package[5];
       
        int invoiceNumber;
        String fromCity, toCity, orderDate, deliveryDate;
        double price;
       
        for(int i=0; i<5; i++){
            invoiceNumber = sc.nextInt();
            fromCity = sc.next();
            toCity = sc.next();
            orderDate = sc.next();
            deliveryDate = sc.next();
            price = sc.nextDouble();
            c[i] = new Package(invoiceNumber, fromCity, toCity, orderDate, deliveryDate, price);
        }
       
        String str1 = sc.next();
        String str2 = sc.next();
        System.out.println(countOrdersDeliveryInAWeek(c, str1));
        Package result=searchPackageByCity(c, str2);
        System.out.println(result.getPrice());
        
    }
   
    public static int countOrdersDeliveryInAWeek(Package[] p, String str){
        int count = 0;
        for(int i=0; i<p.length; i++){
            if(p[i].getFromCity().equals(str)){
            	int t=Integer.parseInt(p[i].getDeliveryDate().substring(0,2)) - Integer.parseInt(p[i].getOrderDate().substring(0,2));
                if(t <= 7){
                    count++;
                }
            }
        }
        return count;
    }
   
 public static Package searchPackageByCity(Package[] p, String str){
        Package temp;
        for(int i=0; i<p.length; i++){
            for(int j=0; j<p.length; j++){
                if(p[i].getPrice() < p[j].getPrice()){
                    temp = p[i];
                    p[i] = p[j];
                    p[j] = temp;
                }
            }
        }
        int loc = 0;
        for(int i=0; i<p.length; i++){
            if(p[i].getToCity().equals(str)){
                loc++;
                if(loc == 2)
                    return p[i];
            }
        }
        return null;
    }
}

class Package{
   
    private int invoiceNumber;
    private String fromCity, toCity, orderDate, deliveryDate;
    private double price;
   
    Package(int invoiceNumber, String fromCity, String toCity, String orderDate, String deliveryDate, double price){
        this.invoiceNumber = invoiceNumber;
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.price = price;
    }
    String getFromCity(){
        return this.fromCity;
    }
   
    String getToCity(){
        return this.toCity;
    }
   
    String getOrderDate(){
        return this.orderDate;
    }
   
    String getDeliveryDate(){
        return this.deliveryDate;
    }
   
    double getPrice(){
        return this.price;
    }
}