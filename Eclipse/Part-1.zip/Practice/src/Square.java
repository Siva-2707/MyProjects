import java.util.*;
public class Square {
	public static void main(String arge[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n<0) {
			System.out.println("Wrong Input");
		}
		else {
			int temp=n,digit=0;
			while(temp>0) {
				digit++;
				temp/=10;
			}
			if(n==(n*n)%Math.pow(10, digit))
				System.out.println("Correct Number");
			else
				System.out.println("Incorrect Number");
		}
	}
}
