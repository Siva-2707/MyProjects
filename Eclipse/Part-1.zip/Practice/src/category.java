import java.util.Scanner;

public class category {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		char firstletter=input.charAt(0);
		if(Character.isUpperCase(firstletter))
			System.out.println("UPPER ALPHABET");
		else if(Character.isLowerCase(firstletter))
			System.out.println("lower alphabet");
		else if(Character.isDigit(firstletter))
			System.out.println("Number");
		else
			System.out.println("Symbol");

	}

}
