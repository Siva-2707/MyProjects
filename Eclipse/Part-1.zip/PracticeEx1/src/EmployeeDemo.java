public class EmployeeDemo {
public static void main(String args[]){
Employee employee1= new Employee("jirhehb","siarpha",35,70,776.0);
System.out.println("Value of idCounter : " + Employee.getIdCounter());
System.out.println("Name :"+employee1.getName());
System.out.println("Designation :"+employee1.getDesignation());
System.out.println("ssnNo :"+employee1.getSsnNo());
System.out.println("Age :"+employee1.getAge());
System.out.println("Salary :"+employee1.getSalary());

Employee employee2= new Employee("ycrdzsi","voivkqr",32,87,484.0);
System.out.println("Value of idCounter : " + Employee.getIdCounter());
System.out.println("Name :"+employee2.getName());
System.out.println("Designation :"+employee2.getDesignation());
System.out.println("ssnNo :"+employee2.getSsnNo());
System.out.println("Age :"+employee2.getAge());
System.out.println("Salary :"+employee2.getSalary());

Employee employee3= new Employee("txdxrzv","azpjbbb",4,63,369.0);
System.out.println("Value of idCounter : " + Employee.getIdCounter());
System.out.println("Name :"+employee3.getName());
System.out.println("Designation :"+employee3.getDesignation());
System.out.println("ssnNo :"+employee3.getSsnNo());
System.out.println("Age :"+employee3.getAge());
System.out.println("Salary :"+employee3.getSalary());

Employee employee4= new Employee("pefjukm","mctpbqe",36,0,951.0);
System.out.println("Value of idCounter : " + Employee.getIdCounter());
System.out.println("Name :"+employee4.getName());
System.out.println("Designation :"+employee4.getDesignation());
System.out.println("ssnNo :"+employee4.getSsnNo());
System.out.println("Age :"+employee4.getAge());
System.out.println("Salary :"+employee4.getSalary());

Employee employee5= new Employee("shbrzke","lpcnymz",51,86,181.0);
System.out.println("Value of idCounter : " + Employee.getIdCounter());
System.out.println("Name :"+employee5.getName());
System.out.println("Designation :"+employee5.getDesignation());
System.out.println("ssnNo :"+employee5.getSsnNo());
System.out.println("Age :"+employee5.getAge());
System.out.println("Salary :"+employee5.getSalary());

}
}