import java.util.Random;
public class Test{
	public static void main(String args[]) {
	Test t1=new Test();
		t1.rollDice();
		t1.rollDice();
	}
void rollDice() {
	Random rand=new Random();
	System.out.println(rand.nextInt(5)+1);
	
}
}