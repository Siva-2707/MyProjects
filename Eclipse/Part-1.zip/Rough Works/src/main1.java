import java.util.*;
public class main1 {
		static int a, b;
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		b = sc.nextInt();
		ChildOne ob1 = new ChildOne();
		ChildTwo ob2 = new ChildTwo();
		System.out.println(ob1.filter(a, b));
		System.out.println(ob2.filter(a, b));
			
			}
		
	}


class ChildOne extends main1{
	
	public String filter(int a, int b){
		
		StringBuffer sb = new StringBuffer();
		for(int i=a;i<=b;i++) {
				if(isHappyNumber(i))
				sb.append(i+" ");
				
		}
		
		return sb.toString();
	}
	public boolean isHappyNumber(int n) {
		int sum;
		do {
			sum=0;
			while(n!=0) {
				int dig = n%10;
				sum+= dig*dig;
				n/=10;
			}
			
			n=sum;
		}while(n!=1 && n!=4);
		
		if(n==1)
			return true;
		else
			return false;
	}
}

class ChildTwo extends main1{
	public String filter(int a, int b){
		
		
		StringBuffer sb = new StringBuffer();
		
		for(int i=a;i<=b;i++) {
			if(i==1)
				continue;
			int flag = 0;
			
			for(int j=2;j<i;j++) {
				if(i%j==0) {
					flag =1;
					break;
				}
			}
			
			if(flag==0)
				sb.append(i+" ");
			
		}
		
		
			return sb.toString();
	}
	
}
