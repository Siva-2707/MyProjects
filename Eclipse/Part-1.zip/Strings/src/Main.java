import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String str1="ABcdefghijklmnopqrstuvwxyz";
		System.out.println(str1.length());  // Gives the length of the string.
		String a = "Con", b="cat";
		System.out.println(a+b);  // Concatenation Way 1
		String c= a.concat(b);	  // Concatenation Way 2	
		System.out.println(c);

		System.out.println(a.toUpperCase()); // To convert all the character in the string to upper case.
		System.out.println(a.toLowerCase()); // Same for lower case.
		
		String name = "Siva, Rajesh, Vishnu, Bharadhan";
		String split[]= name.split(", ");   // Split function.
		for(String x:split) {
			System.out.print(x+"  ");
			System.out.println(x);
		}
		String s1 ="Sivarajesh", s2= "varj";
		System.out.println("Contains Status:  "+s1.contains(s2));  // Contains method;
		
		int n= s1.length();
		int m=s2.length();
		for(int i=0;i<n-m;i++) {
			if(s1.substring(i,i+m).equals(s2)) {
				System.out.println("Contains Status: true");
				break;}
		}
		
		
		// String Buffer and String Builder.
		// These are used to make the string mutable.
		
		
		StringBuffer sbf = new StringBuffer();
		sbf.append("Siva");
		System.out.println(sbf);
		sbf.append("Rajesh");
		System.out.println(sbf);
		
		System.out.println(sbf.reverse());
		System.out.println(sbf.substring(0,5));
		
		//The main difference is that StringBuffer is thread safe and StringBuilder is'nt.
		// It's always better to use StringBuffer.
		StringBuffer sb = new StringBuffer();
		String test =sc.next();
		sb.append(test);
		String result = sb.reverse().toString();  // To string method is used to convert StringBuffer to String.
		if(test.equals(result))
			System.out.println("Palindrome");
		else
			System.out.println("Not a palindrome");
		
		System.out.println(sb);
	}

}
