import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Read {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		// This will thow an IOException so, it must be handled.
//		int a=System.in.read(); //Reads byte data ranging from 0 to 255. 
//		System.out.println((char)a); // Displays the ascii value only.
										// And can display only one character at a time.
		
		
		//In order to overcome this Scanner and BufferReader methods are used.
		
		//Scanner class is most commonly used.
		
		//BufferReader - To create an object of BufferReader first Object of InputStreamReader must be created.
		InputStreamReader in = new InputStreamReader(System.in); //
		
		//The InputStreamReader converts the byte source into character stream. And it is passed to BufferReader.
		BufferedReader br = new BufferedReader(in);
		
		int i= Integer.parseInt(br.readLine()); //It only reads string type. So it must be converted to integer by using parse.
		System.out.println(i);
		String s = br.readLine();
		System.out.println(s);
		
		
		
		
	}

}
