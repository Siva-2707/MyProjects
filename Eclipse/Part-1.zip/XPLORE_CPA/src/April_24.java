import java.util.*;
public class April_24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		EduProgram Epro[] = new EduProgram[4];
		for(int i=0;i<4;i++) {
			Epro[i]=new EduProgram(sc.next(),sc.next(),sc.nextInt(),sc.nextBoolean(),sc.nextBoolean());
		}
		String input = sc.next();
		
		String output1 =findEduProgramClassification(Epro);
		if(output1!=null)
			System.out.println(output1);
		else
			System.out.println("EduPrograms are not available now");
		
		EduProgram e[] = findEduProgramBySponsor(Epro, input);
		if(e==null) {
			System.out.println("No EduProgram is available for the given Sponsor");
		}
		else {
			for(int i=0;i<e.length;i++) {
				System.out.println(e[i].getEduProgramName());
				System.out.println(e[i].getNoOfPeopleAtteded());
			}
		}
			
		
	}
	public static String findEduProgramClassification(EduProgram e[]) {
		for(int i=0;i<4;i++) {
			if(e[i].isStillAvailable()&&e[i].isWithinCountry()) {
				if(e[i].getNoOfPeopleAtteded()>=1000)
					return "EverGreen";
				if(e[i].getNoOfPeopleAtteded()<500)
					return "Emerging Star";
			}
		}
		return null;
	}
	
	public static EduProgram[] findEduProgramBySponsor(EduProgram e[] , String input){
		int count=0;
		for(int i=0;i<4;i++) {
			if(e[i].getSponsor().equals(input))
				count++;
		}
		if (count==0)
			return null;
		EduProgram ed[] = new EduProgram[count];
		int temp1=0;
		for(int i=0;i<4;i++) {
			if(e[i].getSponsor().equals(input)) {
				ed[temp1++]=e[i];
			}
		}
		for(int i=0;i<count;i++) {
			EduProgram temp[]=new EduProgram[count];
			for(int j=0;j<count;j++) {
				if(ed[i].getNoOfPeopleAtteded()<ed[j].getNoOfPeopleAtteded()) {
					temp[i]=ed[i];
				ed[i]=ed[j];
				ed[j]=temp[i];
				}
			}
		}
		
		return ed;
	}
	
}
class EduProgram{
	private String eduProgramName , sponsor;
	private int noOfPeopleAtteded;
	private boolean stillAvailable, withinCountry;
	
	EduProgram(String eduProgramName, String sponsor, int noOfPeopleAtteded, boolean stillAvailable,
			boolean withinCountry) {
		this.eduProgramName = eduProgramName;
		this.sponsor = sponsor;
		this.noOfPeopleAtteded = noOfPeopleAtteded;
		this.stillAvailable = stillAvailable;
		this.withinCountry = withinCountry;
	}

	public String getEduProgramName() {
		return eduProgramName;
	}

	public String getSponsor() {
		return sponsor;
	}

	public int getNoOfPeopleAtteded() {
		return noOfPeopleAtteded;
	}

	public boolean isStillAvailable() {
		return stillAvailable;
	}

	public boolean isWithinCountry() {
		return withinCountry;
	}
	
}