import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ResortGuest guest[]=new ResortGuest[4];
		
		//Sample Input 1
		/*guest[0]=new ResortGuest(101,"Kamal","12-sep-2020",2,"veg",5000);
		guest[1]=new ResortGuest(102, "Sudha","13-apr-2020",1,"non-veg",2300);
		guest[2]=new ResortGuest(103, "Vipin","11-apr-2020",3,"non-veg",7500);
		guest[3]=new ResortGuest(104, "Jagdeep","15-Jun-2020",1,"veg",1200); 
		
		//Sample Input 2
		guest[0]=new ResortGuest(101,"Arun","12-mar-2020",2,"veg",5000);
		guest[1]=new ResortGuest(102,"Karan","13-apr-2020",1,"veg",2300);
		guest[2]=new ResortGuest(103,"Manu","11-Mar-2020",3,"veg",7500);
		guest[3]=new ResortGuest(104,"Ritu","15-Jan-2020",1,"veg",1200); */
		
		int guestId;
		String guestName;
		String dateOfBooking;
		int noOfRoomsBooked;
		String mealOption;
		double totalBill;
		for(int i=0;i<4;i++) {
			guestId=sc.nextInt();
			guestName=sc.next();
			dateOfBooking=sc.next();
			noOfRoomsBooked=sc.nextInt();
			mealOption=sc.next();
			totalBill=sc.nextDouble();
			guest[i]=new   ResortGuest(guestId,guestName,dateOfBooking,noOfRoomsBooked,mealOption,totalBill);
		}
		String month=sc.next();
		String variety=sc.next();
		int totalNoOfRooms= findNumberOfRoomsInMonth(guest, month);
		
		if(totalNoOfRooms==0)
			System.out.println("No rooms booked");
		else
			System.out.println(totalNoOfRooms);
		
		int option =searchResortGuestByMealOpted(guest, variety);
		
		if(option==0)
			System.out.println("No such meal");
		else
			System.out.println(option);
		
		
		
	}
	
	public static int findNumberOfRoomsInMonth(ResortGuest guest[],String month) {
		int totalNoOfRooms=0;
		for(int i=0;i<4;i++) {
			String check=(guest[i].getDateOfBooking()).substring(3,6);
			if(check.toLowerCase().equals(month.toLowerCase()))
				totalNoOfRooms+=guest[i].getNoOfRoomsBooked();
		}
		return totalNoOfRooms;
	}
	
	public static int searchResortGuestByMealOpted(ResortGuest guest[],String variety) {
		double sortArray[]=new double[4];
		int k=0;
		for(int i=0;i<4;i++) {
			if(guest[i].getMealOption().equals(variety)) {
				sortArray[k]=guest[i].getTotalBill();
				k++;
			}
		}
		if(k==0)
			return 0;
		for(int i=0;i<k;i++) {
			for(int j=0;j<k;j++) {
				if(sortArray[i]>sortArray[j]) {
					double temp=sortArray[i];
					sortArray[i]=sortArray[j];
					sortArray[j]=temp;
				}
			}
		}
		int id=0;
		for(int i=0;i<4;i++) {
			if(sortArray[1]==guest[i].getTotalBill()) {
				id=guest[i].getGuestId();
			}
		}
		return id;
	}

}
