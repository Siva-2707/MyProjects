import java.util.Arrays;
import java.util.Scanner;

public class May_09 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Antenna a[] = new Antenna[4];
		for(int i=0;i<4;i++) {
			a[i] = new Antenna(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());	
		}
		String str= sc.next();
		double val=sc.nextDouble();
		int output1= searchAntennaByName(a, str);
		if(output1!=0)
		System.out.println(output1);
		else
			System.out.println("There is no antenna with the given parameter");
		Antenna b[]= sortAntennaByVswr(a, val);
		if(b==null) {
			System.out.println("No antenna found");
		}
		else {
			for(int i=0;i<b.length;i++) {
				System.out.println(b[i].getProjectLead());
			}
		}

	}
	public static int searchAntennaByName(Antenna a[],String str) {
		for(int i=0;i<a.length;i++) {
			if(a[i].getAntennaName().equals(str))
				return a[i].getAntennaId();
		}
		return 0;
	}
	public static Antenna[] sortAntennaByVswr(Antenna a[],double val) {
		int count=0;
		for(int i=0;i<a.length;i++) {
			if(a[i].getAntennaVSWR()<val)
				count++;
		}
		if(count==0)
			return null;
		Antenna b[] = new Antenna[count];
		count=0;
		for(int i=0;i<a.length;i++) {
			if(a[i].getAntennaVSWR()<val) {
				b[count++]=a[i];
			}
		}
		for(int i=0;i<b.length;i++) {
			Antenna temp[]= new Antenna[b.length];
				for(int j=0;j<b.length;j++) {
				if(b[i].getAntennaVSWR()<b[j].getAntennaVSWR()) {
					temp[i]=b[i];
					b[i]=b[j];
					b[j]=temp[i];	
				}
			}
		}
		return b;
	}

}
class Antenna{
	private int antennaId;
	private String antennaName, projectLead;
	private double antennaVSWR;
	
	public Antenna(int antennaId, String antennaName, String projectLead, double antennaVSWR) {
		this.antennaId = antennaId;
		this.antennaName = antennaName;
		this.projectLead = projectLead;
		this.antennaVSWR = antennaVSWR;
	}

	public int getAntennaId() {
		return antennaId;
	}

	public String getAntennaName() {
		return antennaName;
	}

	public String getProjectLead() {
		return projectLead;
	}

	public double getAntennaVSWR() {
		return antennaVSWR;
	}
}
