import java.util.Scanner;

public class May_30 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Vessel ves[] = new Vessel [4];
		for(int i=0;i<4;i++) {
			int id =sc.nextInt();
			String brand = sc.next();
			int cap =sc.nextInt();
			String mat =sc.next();
			double price = sc.nextDouble();
			ves[i] = new Vessel(id,brand,cap,mat,price);
		}
		String type = sc.next();
		String brand = sc.next();
		
		int output1 = getAvgPriceBasedOnMaterial(ves, type);
		if(output1 !=0 )
			System.out.println(output1);
		else 
			System.out.println("There is no matching vessels");
			
		
		Vessel v = getVesselBySecondHighestPrice(ves, brand);
		
		if(v==null)
			System.out.println("Vessels are not available for the given brand");
		else
		{
			System.out.println(v.getMaterial());
			System.out.println(v.getVesselId());
		}
		
		

	}
	
	public static int getAvgPriceBasedOnMaterial(Vessel ves[], String type) {
		int sum = 0, count = 0; 
		for(int i=0;i<4;i++) {
			if(ves[i].getMaterial().equalsIgnoreCase(type)) {
				sum+= ves[i].getPrice();
				count++;
			}	
		}
		if(count!=0)
			return sum/count;
		
		return 0;
	}
	
	public static Vessel getVesselBySecondHighestPrice(Vessel ves[], String brand ) {
		Vessel temp[] = new Vessel[4];
		for(int i=0;i<4;i++) {
			for(int j=0;j<4;j++) {
				if(ves[i].getPrice()<ves[j].getPrice()) {
					temp[i] = ves[i];
					ves[i] = ves[j];
					ves[j] = temp[i];
				}
			}
		}
		int count=0;
		for(int i=0;i<4;i++) {
			if(ves[i].getVesselBrand().equalsIgnoreCase(brand)) {
				count++;
			}
			if(count==2)
				return ves[i];
		}
			return null;
	}

}

class Vessel{
	private int vesselId;
	private String vesselBrand;
	private int capacity;
	private String material;
	private double price;
	
	
	public Vessel(int vesselId, String vesselBrand, int capacity, String material, double price) {
		this.vesselId = vesselId;
		this.vesselBrand = vesselBrand;
		this.capacity = capacity;
		this.material = material;
		this.price = price;
	}


	public int getVesselId() {
		return vesselId;
	}


	public String getVesselBrand() {
		return vesselBrand;
	}


	public int getCapacity() {
		return capacity;
	}


	public String getMaterial() {
		return material;
	}


	public double getPrice() {
		return price;
	}

	
}
