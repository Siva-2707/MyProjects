import java.util.Scanner;

public class MyClass {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	Engine e[] = new Engine[4];
	for(int i=0; i<4 ;i++) {
		e[i]=new Engine(sc.nextInt(), sc.next(), sc.next(), sc.nextDouble());
	}
	String type = sc.next(), company = sc.next();
	
int avg = findAvgEnginePriceByType(e, type);
if(avg!=0)
	System.out.println(avg);
else
	System.out.println("There is no engine with given type");
Engine obj[] = searchEngineByName(e, company);
if(obj!=null)
	for(Engine arr:obj)
	System.out.println(arr.getEngineId());
else
	System.out.println("There is no engine with the given name");


	}
public static int findAvgEnginePriceByType(Engine e[],String type) {
	int count=0, sum=0;
	for(int i=0;i<4;i++) {
		if(e[i].getEngineType().equals(type)) {
			count++;
			sum+=e[i].getEnginePrice();
		}
	
	}
	if(count!=0)
		return sum/count;
	return 0;
}
public static Engine[] searchEngineByName(Engine e[], String company) {
	Engine temp;
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			if(e[i].getEngineId()<e[j].getEngineId()) {
				temp=e[i];
				e[i]=e[j];
				e[j]=temp;
			}
		}
	}
	int count=0;
	for(Engine arr:e) {
		if(arr.getEngineName().equals(company))
			count++;
	}
	if(count==0)
		return null;
	Engine arr[] = new Engine[count];
	for(int i=0,j=0;i<4;i++) {
		if(e[i].getEngineName().equals(company))
		arr[j++]=e[i];
	}
	return arr;
}

	

}
class Engine{
	private int engineId;
	private String engineName, engineType;
	private double enginePrice;
	
	public Engine(int engineId, String engineName, String engineType, double enginePrice) {
		super();
		this.engineId = engineId;
		this.engineName = engineName;
		this.engineType = engineType;
		this.enginePrice = enginePrice;
	}

	public int getEngineId() {
		return engineId;
	}

	public String getEngineName() {
		return engineName;
	}

	public String getEngineType() {
		return engineType;
	}

	public double getEnginePrice() {
		return enginePrice;
	}	
}
