
package abstract_factory_example;

/**
 *
 * @author bethan
 */
public abstract class Handlebar {
    
    abstract void getDescription();
    
}
