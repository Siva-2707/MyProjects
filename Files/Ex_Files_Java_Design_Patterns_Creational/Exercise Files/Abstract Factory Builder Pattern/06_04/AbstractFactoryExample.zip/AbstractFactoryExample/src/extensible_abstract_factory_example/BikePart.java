
package extensible_abstract_factory_example;

/**
 *
 * @author bethan
 */
abstract class BikePart {  
    
    abstract void getDescription();
    
    
}
