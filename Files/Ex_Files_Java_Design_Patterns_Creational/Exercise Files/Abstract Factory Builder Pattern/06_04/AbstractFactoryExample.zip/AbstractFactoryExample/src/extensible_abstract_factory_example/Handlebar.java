
package extensible_abstract_factory_example;

/**
 *
 * @author bethan
 */
public abstract class Handlebar extends BikePart {
    
    @Override
    abstract void getDescription();
    
}
