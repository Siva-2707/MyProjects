
package extensible_abstract_factory_example;

/**
 *
 * @author bethan
 */
public abstract class Tire extends BikePart {
    
    abstract void getDescription();
    
}
