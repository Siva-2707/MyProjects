
package complex_builder_example;

import java.util.ArrayList;

/**
 *
 * @author bethan
 */
public class House {

    private ArrayList listOfRooms;
    
    public House(ArrayList listOfRooms) {
        this.listOfRooms = listOfRooms;
    }
    
}
