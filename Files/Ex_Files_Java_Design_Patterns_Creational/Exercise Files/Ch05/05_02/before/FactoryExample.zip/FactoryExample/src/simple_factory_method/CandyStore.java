package simple_factory_method;

import java.util.ArrayList;

/**
 *
 * @author bethan
 */
public class CandyStore {

    public static void main(String[] args) {
        
        
        
        

    }

    public static Candy getCandy(String type) {
        switch (type) {
            case "hard candy":
                return new HardCandy();
            case "chocolate":
                return new Chocolate();
            default:
                return null;
        }
    }

    public static ArrayList getCandyPackage(int quantity, String type) {
        Candy candy = getCandy(type);
        ArrayList candyPackage = candy.makeCandyPackage(quantity);
        return candyPackage;
    }

}
