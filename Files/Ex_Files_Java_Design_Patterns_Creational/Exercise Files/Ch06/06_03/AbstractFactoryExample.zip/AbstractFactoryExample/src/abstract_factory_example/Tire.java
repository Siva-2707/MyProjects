
package abstract_factory_example;

/**
 *
 * @author bethan
 */
public abstract class Tire {
    
    abstract void getDescription();
    
}
