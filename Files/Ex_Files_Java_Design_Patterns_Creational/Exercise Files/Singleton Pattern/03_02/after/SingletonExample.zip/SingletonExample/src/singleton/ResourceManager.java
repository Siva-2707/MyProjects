
package singleton;

/**
 *
 * @author bethan
 */
public class ResourceManager {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {            

        PrintSpooler spooler = PrintSpooler.getInstance();
                          
    }

}
