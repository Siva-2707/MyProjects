
package collections_example;

/**
 *
 * @author bethan
 */
public class NetworkDriveConnector {
    
    // code to manage access to a Network Drive
    
}
