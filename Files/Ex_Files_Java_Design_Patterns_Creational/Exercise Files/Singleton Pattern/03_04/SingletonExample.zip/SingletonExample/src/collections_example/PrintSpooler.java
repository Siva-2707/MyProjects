
package collections_example;

/**
 *
 * @author bethan
 */

public class PrintSpooler extends Spooler {
    
// Code to manage access to a printer           
    
}
